# Baghouse.Shoper.Shopee — 3-Tier Deployment & Configuration Guide

**Project:** Baghouse.Shoper.Shopee (E-commerce — bags, wallets, belts, bottles, umbrellas, key chains, idols)
**Author:** Santhosh Tonanki — DevOps Engineer
**Stack:** Nginx (Web) | Node.js 20 + Express (App) | MySQL 8.0 (DB)
**Target OS:** RHEL 9 / Rocky Linux 9 / Amazon Linux 2023 (dnf based)
**Document version:** 1.0

---

## 1. Architecture Overview

Three EC2 instances, one per tier. Traffic flows only downward; no tier is skipped.

```
        Internet (Users)
              |
              |  HTTP 80 / HTTPS 443
              v
   +---------------------------+
   |  WEB TIER  (Public)       |
   |  nginx                    |
   |  - serves frontend files  |
   |  - reverse proxy /api/    |
   +---------------------------+
              |  TCP 5000 (private subnet only)
              v
   +---------------------------+
   |  APP TIER  (Private)      |
   |  Node.js 20 + Express     |
   |  systemd: baghouse.service|
   |  runs as user 'baghouse'  |
   +---------------------------+
              |  TCP 3306 (private subnet only)
              v
   +---------------------------+
   |  DB TIER   (Private)      |
   |  MySQL 8.0 (mysqld)       |
   |  database: baghouse       |
   +---------------------------+
```

### Why this split
| Tier | Responsibility | Never does |
|---|---|---|
| Web | Static UI, SSL termination, caching, rate limit | Business logic, DB queries |
| App | REST APIs, JWT auth, bcrypt hashing, SQL queries | Serving public traffic directly |
| DB | Persistent storage only | Public internet exposure |

---

## 2. Infrastructure & Package Requirements Matrix

| Server | Name tag | Recommended spec | Packages to install | Inbound ports |
|---|---|---|---|---|
| Web Server | `baghouse-web` | t3.micro (1 vCPU, 1 GB) | `nginx`, `curl`, `unzip` | 80, 443 from `0.0.0.0/0`; 22 from your IP |
| App Server | `baghouse-app` | t3.small (2 vCPU, 2 GB) | `nodejs:20`, `npm`, `git`, `unzip`, `mysql` (client) | 5000 from **web SG only**; 22 from bastion/your IP |
| DB Server | `baghouse-db` | t3.medium (2 vCPU, 4 GB) | `mysql-server` (8.0) | 3306 from **app SG only**; 22 from bastion/your IP |

### Security Group rules (write them as SG-to-SG, not open CIDR)

| SG | Rule | Source |
|---|---|---|
| `sg-baghouse-web` | TCP 80, 443 | 0.0.0.0/0 |
| `sg-baghouse-app` | TCP 5000 | `sg-baghouse-web` |
| `sg-baghouse-db` | TCP 3306 | `sg-baghouse-app` |
| all | TCP 22 | your office/home IP only |

### Note down these values before starting
```text
WEB_PUBLIC_IP   = <fill>
APP_PRIVATE_IP  = <fill>
DB_PRIVATE_IP   = <fill>
DB_APP_PASSWORD = <generate a strong password>
JWT_SECRET      = <openssl rand -hex 32>
```

---

## 3. DATABASE TIER SETUP (baghouse-db)

Database first — app tier fails at startup if the DB is unreachable.

### Step 1 — Install MySQL 8.0
```bash
dnf install mysql-server -y
systemctl enable mysqld
systemctl start mysqld
systemctl status mysqld
```

### Step 2 — Secure the installation
```bash
mysql_secure_installation
```
Answer: set a strong root password, remove anonymous users **Y**, disallow remote root login **Y**, remove test database **Y**, reload privileges **Y**.

> If MySQL generated a temporary root password, read it with:
> `grep 'temporary password' /var/log/mysqld.log`

### Step 3 — Allow remote connections from the App tier
Edit `/etc/my.cnf.d/mysql-server.cnf` (or `/etc/my.cnf`) and set:
```ini
[mysqld]
bind-address = 0.0.0.0
```
Then:
```bash
systemctl restart mysqld
ss -lntp | grep 3306
```

### Step 4 — Create the application database user
Never let the application connect as `root`.
```bash
mysql -u root -p
```
```sql
CREATE DATABASE IF NOT EXISTS baghouse
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER 'baghouse_app'@'%' IDENTIFIED BY 'DB_APP_PASSWORD';
GRANT SELECT, INSERT, UPDATE, DELETE ON baghouse.* TO 'baghouse_app'@'%';
FLUSH PRIVILEGES;
EXIT;
```
> `'%'` can be tightened to the app private IP: `'baghouse_app'@'10.0.2.25'`.

### Step 5 — Load schema and master data
`database/schema.sql` from the repo creates all tables (users, categories, brands, products, orders, order_items, service_requests) and seeds categories, brands and sample products.

Copy the file to the DB server and load it:
```bash
# from your laptop
scp -i key.pem database/schema.sql ec2-user@<DB_PUBLIC_OR_BASTION>:/tmp/

# on DB server
mysql -u root -p < /tmp/schema.sql
```

### Step 6 — Verify
```bash
mysql -u root -p -e "USE baghouse; SHOW TABLES; SELECT COUNT(*) FROM products; SELECT name,slug FROM categories;"
```
Expected: 7 tables, and product rows seeded (American Tourister, VIP, Skybags …).

### Step 7 — Firewall (if firewalld is running)
```bash
firewall-cmd --permanent --add-port=3306/tcp
firewall-cmd --reload
```

---

## 4. APPLICATION TIER SETUP (baghouse-app)

### Step 1 — Enable Node.js 20
RHEL 9 ships Node.js 16 by default; Express 4 + mysql2 need Node 18+.
```bash
dnf module list nodejs
dnf module disable nodejs -y
dnf module enable nodejs:20 -y
dnf install nodejs -y
node -v      # expect v20.x
npm -v
```

### Step 2 — Create the application system user
The service must never run as root.
```bash
useradd --system --home /app --shell /sbin/nologin \
        --comment "baghouse system user" baghouse
```

### Step 3 — Create the standard app directory and deploy code
```bash
mkdir -p /app
cd /app
```
Option A — from GitHub (recommended):
```bash
dnf install git -y
git clone https://github.com/Santhoshtonanki/Baghouse.Shoper.Shopee.git /tmp/baghouse
cp -r /tmp/baghouse/* /app/
```
Option B — from a zip artifact:
```bash
curl -o /tmp/baghouse.zip <ARTIFACT-URL>
cd /app && unzip -o /tmp/baghouse.zip
```

Resulting layout on the server:
```text
/app
├── backend/   (server.js, package.json, .env)
├── frontend/  (index.html, app.js, styles.css)
└── database/  (schema.sql)
```

### Step 4 — Install npm dependencies
```bash
cd /app/backend
npm install --omit=dev
```
Installs: express, mysql2, jsonwebtoken, bcryptjs, cors, dotenv.

### Step 5 — Create the environment file
```bash
vim /app/backend/.env
```
```env
PORT=5000
DB_HOST=<DB_PRIVATE_IP>
DB_PORT=3306
DB_USER=baghouse_app
DB_PASSWORD=<DB_APP_PASSWORD>
DB_NAME=baghouse
JWT_SECRET=<output of: openssl rand -hex 32>
```
Lock the file down — it holds credentials:
```bash
chown -R baghouse:baghouse /app
chmod 600 /app/backend/.env
```

### Step 6 — Create the systemd service unit
```bash
vim /etc/systemd/system/baghouse.service
```
```ini
[Unit]
Description = Baghouse Shopee Backend Service
After = network-online.target
Wants = network-online.target

[Service]
User=baghouse
Group=baghouse
WorkingDirectory=/app/backend
EnvironmentFile=/app/backend/.env
ExecStart=/usr/bin/node /app/backend/server.js
SyslogIdentifier=baghouse
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```
> `EnvironmentFile` loads `.env` into the process, and `dotenv` in `server.js` also reads it — both paths work.

### Step 7 — Load, enable and start the service
```bash
systemctl daemon-reload
systemctl enable baghouse
systemctl start baghouse
systemctl status baghouse
```

### Step 8 — Verify the app tier locally
```bash
curl http://localhost:5000/api/products
curl http://localhost:5000/api/categories
journalctl -u baghouse -f
```
Expect a JSON array of products. If you get a DB error, re-check `.env` and the DB security group.

### Step 9 — Firewall
```bash
firewall-cmd --permanent --add-port=5000/tcp
firewall-cmd --reload
```

---

## 5. WEB TIER SETUP (baghouse-web)

The frontend calls the API using a relative path (`const API = '/api'`), so nginx serves the static files and proxies `/api/` to the app tier. No source code change is needed.

### Step 1 — Install nginx
```bash
dnf install nginx -y
systemctl enable nginx
systemctl start nginx
```

### Step 2 — Deploy the frontend files
```bash
rm -rf /usr/share/nginx/html/*
# copy only the frontend folder from the repo
cp -r /tmp/baghouse/frontend/* /usr/share/nginx/html/
chown -R nginx:nginx /usr/share/nginx/html
restorecon -Rv /usr/share/nginx/html
```

### Step 3 — Configure the reverse proxy
```bash
vim /etc/nginx/conf.d/baghouse.conf
```
```nginx
server {
    listen       80;
    server_name  baghouse.shoper.shopee _;

    root  /usr/share/nginx/html;
    index index.html;

    # Static frontend
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API traffic to the App Tier
    location /api/ {
        proxy_pass         http://<APP_PRIVATE_IP>:5000;
        proxy_http_version 1.1;
        proxy_set_header   Host              $host;
        proxy_set_header   X-Real-IP         $remote_addr;
        proxy_set_header   X-Forwarded-For   $proxy_add_x_forwarded_for;
        proxy_set_header   X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
    }

    gzip on;
    gzip_types text/css application/javascript application/json image/svg+xml;

    error_page 502 503 504 /50x.html;
    location = /50x.html { root /usr/share/nginx/html; }
}
```
> Keep `proxy_pass` **without a trailing slash** — the backend routes already start with `/api/`.

### Step 4 — SELinux permission for outbound proxy
Without this, nginx returns 502 on every API call.
```bash
setsebool -P httpd_can_network_connect 1
```

### Step 5 — Test and reload
```bash
nginx -t
systemctl reload nginx
firewall-cmd --permanent --add-service=http --add-service=https
firewall-cmd --reload
```

### Step 6 — Optional: HTTPS with Let's Encrypt
```bash
dnf install certbot python3-certbot-nginx -y
certbot --nginx -d baghouse.shoper.shopee
systemctl enable --now certbot-renew.timer
```

---

## 6. Verification Checklist

Run top to bottom. Stop at the first failure and fix that tier.

| # | Where | Command | Expected |
|---|---|---|---|
| 1 | DB | `systemctl is-active mysqld` | `active` |
| 2 | DB | `mysql -u root -p -e "USE baghouse; SHOW TABLES;"` | 7 tables |
| 3 | App | `telnet <DB_PRIVATE_IP> 3306` or `mysql -h <DB_PRIVATE_IP> -u baghouse_app -p` | connects |
| 4 | App | `systemctl is-active baghouse` | `active` |
| 5 | App | `curl -s localhost:5000/api/products \| head` | JSON array |
| 6 | Web | `curl -I http://localhost` | `200 OK` |
| 7 | Web | `curl -s http://localhost/api/categories` | JSON array |
| 8 | Browser | `http://<WEB_PUBLIC_IP>` | Shop UI with products |
| 9 | Browser | Register → Login → Add to cart → Place order | Order saved |
| 10 | DB | `SELECT * FROM orders;` | new row present |

### Promote yourself to admin (after registering once)
```sql
UPDATE users SET role='admin' WHERE email='santhoshtonanki1996@gmail.com';
```

---

## 7. Troubleshooting Matrix

| Symptom | Likely cause | Fix |
|---|---|---|
| `502 Bad Gateway` on `/api/` | SELinux blocks nginx outbound | `setsebool -P httpd_can_network_connect 1` |
| `502` and SELinux already set | App service down / wrong IP in `proxy_pass` | `systemctl status baghouse`, verify APP_PRIVATE_IP |
| Service restarts in a loop | Bad `.env` or DB unreachable | `journalctl -u baghouse -n 50` |
| `ER_ACCESS_DENIED_ERROR` | Wrong DB user/password or host grant | Recreate grant for `'baghouse_app'@'%'` |
| `ECONNREFUSED 3306` | `bind-address` still 127.0.0.1, or SG closed | Fix `bind-address`, open 3306 to app SG |
| Products page empty, API works | Schema loaded without seed data | Re-run `schema.sql` |
| `Cannot find module 'express'` | `npm install` run in wrong directory | `cd /app/backend && npm install` |
| Permission denied on `/app` | Ownership not set | `chown -R baghouse:baghouse /app` |
| `node: command not found` in systemd | Wrong ExecStart path | `which node` → use that absolute path |

---

## 8. Day-2 Operations

### Standard commands
```bash
systemctl restart baghouse          # restart app after code change
journalctl -u baghouse -f           # live app logs
tail -f /var/log/nginx/access.log   # web traffic
tail -f /var/log/nginx/error.log    # proxy errors
```

### Deploying a new version
```bash
cd /app && git pull
cd /app/backend && npm install --omit=dev
systemctl restart baghouse
# frontend changes → copy /app/frontend/* to web server html dir, reload nginx
```

### Daily database backup (cron on DB server)
```bash
mkdir -p /backup
crontab -e
```
```cron
0 2 * * * mysqldump -u root -p'<ROOT_PW>' baghouse | gzip > /backup/baghouse-$(date +\%F).sql.gz
0 3 * * * find /backup -name "*.sql.gz" -mtime +7 -delete
```

---

## 9. Security Hardening Checklist

- [ ] App and DB servers in **private subnets**; access only via bastion
- [ ] SSH restricted to known IPs; password auth disabled
- [ ] App never runs as root (`User=baghouse`)
- [ ] DB user has only CRUD grants, not `ALL PRIVILEGES`
- [ ] `.env` is `chmod 600`, owned by `baghouse`, and **never committed to Git**
- [ ] `JWT_SECRET` generated with `openssl rand -hex 32`
- [ ] HTTPS enabled at the web tier; HTTP redirected to HTTPS
- [ ] Nginx rate limiting on `/api/auth/login` to slow brute force
- [ ] Automated daily DB backups verified by a test restore
- [ ] `dnf update -y` scheduled monthly

---

## 10. GitHub Repository Structure

Store this guide alongside the code so the runbook lives with the project.

```text
Baghouse.Shoper.Shopee/
├── README.md
├── backend/
│   ├── server.js
│   ├── package.json
│   └── .env.example          <- commit this, never .env
├── frontend/
│   ├── index.html
│   ├── app.js
│   └── styles.css
├── database/
│   └── schema.sql
└── docs/
    ├── 01-architecture.md
    ├── 02-db-tier-setup.md
    ├── 03-app-tier-setup.md
    ├── 04-web-tier-setup.md
    └── BAGHOUSE-3TIER-DEPLOYMENT-GUIDE.pdf
```

Add a `.gitignore`:
```gitignore
node_modules/
.env
*.log
```

---

## 11. Next DevOps Milestones

Manual setup is Level 1. Repeat the same architecture with increasing automation:

| Level | Goal | Tools |
|---|---|---|
| 1 | Manual 3-tier on EC2 (this document) | ssh, dnf, systemd, nginx |
| 2 | Shell scripts per tier | bash (`db.sh`, `app.sh`, `web.sh`) |
| 3 | Infrastructure as Code | Terraform (VPC, subnets, SGs, EC2) |
| 4 | Configuration as Code | Ansible roles: `mysql`, `nodeapp`, `nginx` |
| 5 | Containerise | Dockerfile per tier + docker-compose |
| 6 | Orchestrate | EKS, Helm chart, RDS for MySQL |
| 7 | CI/CD | GitHub Actions: build → test → deploy |
| 8 | Observability | Prometheus, Grafana, Loki, alerts |

---

*End of document — Baghouse.Shoper.Shopee 3-Tier Deployment & Configuration Guide v1.0*
