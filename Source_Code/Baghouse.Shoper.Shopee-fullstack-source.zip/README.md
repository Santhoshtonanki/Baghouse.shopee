# Baghouse.Shoper.Shopee - Full Stack E-commerce

A beginner-friendly full-stack e-commerce starter for bags, wallets, belts, bottles, umbrellas, key chains, comic/character idols and product service.

## Stack
- Frontend: HTML5, CSS3, Vanilla JavaScript
- Backend: Node.js + Express
- Database: MySQL 8+
- DB driver: mysql2
- Authentication: JWT + bcryptjs

## Project structure
```text
Baghouse.Shoper.Shopee-fullstack/
├── backend/
│   ├── .env.example
│   ├── package.json
│   └── server.js
├── database/
│   └── schema.sql
└── frontend/
    ├── index.html
    ├── styles.css
    └── app.js
```

## 1. Create MySQL database
Run:
```bash
mysql -u root -p < database/schema.sql
```

## 2. Configure backend
```bash
cd backend
cp .env.example .env
npm install
```

Edit `.env`:
```env
PORT=5000
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=baghouse
JWT_SECRET=change_this_to_a_long_random_secret
```

## 3. Start the application
```bash
npm start
```

Open:
```text
http://localhost:5000
```

The Express server serves the frontend and REST APIs.

## Main APIs

### Authentication
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/me`

### Products
- GET `/api/products`
- GET `/api/products/:id`
- POST `/api/products` (admin)
- PUT `/api/products/:id` (admin)
- DELETE `/api/products/:id` (admin)

### Categories
- GET `/api/categories`

### Orders
- POST `/api/orders`
- GET `/api/orders/my`

### Service
- POST `/api/service-requests`
- GET `/api/service-requests/my`

## Demo admin
After registering a user, update that user's role in MySQL:
```sql
UPDATE users SET role='admin' WHERE email='your-email@example.com';
```

## Production notes
Before production, add payment gateway integration, image storage, HTTPS, rate limiting, input validation, email/SMS notifications, proper admin UI, backups, logging, and secure secret management.
